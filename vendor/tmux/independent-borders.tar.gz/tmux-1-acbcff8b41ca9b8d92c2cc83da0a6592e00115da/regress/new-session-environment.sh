#!/bin/sh

. ./regress-common.inc

# new session environment

PATH=/bin:/usr/bin

[ -z "$TEST_TMUX" ] && TEST_TMUX=$(readlink -f ../tmux)
TMUX="$TEST_TMUX -LtestA$$ -f/dev/null"
stop_server $TMUX || exit 1

TERM=$($TMUX start \; set -s exit-empty off \; show -gv default-terminal)
stop_server $TMUX || exit 1
TMP=$(mktemp)
OUT=$(mktemp)
SCRIPT=$(mktemp)
trap "rm -f $TMP $OUT $SCRIPT" 0 1 15

cat <<EOF >$SCRIPT
(
echo TERM=\$TERM
echo PWD=\$(pwd)
echo PATH=\$PATH
echo SHELL=\$SHELL
echo TEST=\$TEST
) >$OUT
EOF

cat <<EOF >$TMP
new -- /bin/sh $SCRIPT
EOF

(cd /; env -i TERM=ansi TEST=test1 PATH=1 SHELL=/bin/sh \
	$TMUX -f$TMP start) || exit 1
sleep 1
(cat <<EOF|cmp -s - $OUT) || exit 1
TERM=$TERM
PWD=/
PATH=1
SHELL=/bin/sh
TEST=test1
EOF

(cd /; env -i TERM=ansi TEST=test2 PATH=2 SHELL=/bin/sh \
	$TMUX -f$TMP new -d -- /bin/sh $SCRIPT) || exit 1
sleep 1
(cat <<EOF|cmp -s - $OUT) || exit 1
TERM=$TERM
PWD=/
PATH=2
SHELL=/bin/sh
TEST=test2
EOF

(cd /; env -i TERM=ansi TEST=test3 PATH=3 SHELL=/bin/sh \
	$TMUX -f/dev/null new -d source $TMP) || exit 1
sleep 1
(cat <<EOF|cmp -s - $OUT) || exit 1
TERM=$TERM
PWD=/
PATH=2
SHELL=/bin/sh
TEST=test2
EOF

stop_server $TMUX || exit 1

exit 0
