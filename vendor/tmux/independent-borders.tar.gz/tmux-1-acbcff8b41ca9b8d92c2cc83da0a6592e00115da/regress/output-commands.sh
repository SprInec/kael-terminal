#!/bin/sh

PATH=/bin:/usr/bin
TERM=screen

[ -z "$TEST_TMUX" ] && TEST_TMUX=$(readlink -f ../tmux)
TMUX="$TEST_TMUX -L${TEST_SOCKET:-testO$$} -f/dev/null"
OUT=/tmp/tmux-output-commands-$$
EXP=/tmp/tmux-output-commands-expected-$$
EXPECTED=$(printf 'one\ntwo')

cleanup()
{
	$TMUX kill-server 2>/dev/null
	rm -f "$OUT" "$EXP"
}
trap cleanup EXIT HUP INT TERM

check_pipe()
{
	i=0
	while [ "$i" -lt 50 ]; do
		cmp -s "$OUT" "$EXP" && return 0
		sleep 0.1
		i=$((i + 1))
	done
	cmp "$OUT" "$EXP"
	exit 1
}

$TMUX kill-server 2>/dev/null
$TMUX new-session -d -x80 -y20 "sh -c 'printf \"\\033]133;A\\007p\\$ \\033]133;B\\007echo\\n\\033]133;C\\007one\\ntwo\\n\\033]133;D;0\\007separator\\n\\033]133;A\\007p\\$ \\033]133;B\\007broken\\n\\033]133;C\\007unfinished\"; exec sleep 100'" || exit 1
sleep 1

$TMUX copy-mode || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -X copy-output || exit 1
[ "$($TMUX show-buffer)" = unfinished ] || exit 1

$TMUX set-buffer sentinel || exit 1
printf unfinished >"$EXP"
: >"$OUT"
$TMUX send-keys -X pipe-output "cat >$OUT" || exit 1
check_pipe
[ "$($TMUX show-buffer)" = sentinel ] || exit 1

: >"$OUT"
$TMUX send-keys -X copy-pipe-output "cat >$OUT" output || exit 1
check_pipe
[ "$($TMUX show-buffer)" = unfinished ] || exit 1
buffer=$($TMUX list-buffers -F '#{buffer_name}' | head -n1)
case "$buffer" in
output[0-9]*) ;;
*) exit 1 ;;
esac
[ "$($TMUX show-buffer -b "$buffer")" = unfinished ] || exit 1

# Paste suppression leaves the buffer list unchanged but still pipes output.
$TMUX set-buffer sentinel || exit 1
buffers=$($TMUX list-buffers -F '#{buffer_name}')
$TMUX send-keys -X copy-output -P || exit 1
[ "$($TMUX show-buffer)" = sentinel ] || exit 1
[ "$($TMUX list-buffers -F '#{buffer_name}')" = "$buffers" ] || exit 1
: >"$OUT"
$TMUX send-keys -X copy-pipe-output -P "cat >$OUT" || exit 1
check_pipe
[ "$($TMUX show-buffer)" = sentinel ] || exit 1
[ "$($TMUX list-buffers -F '#{buffer_name}')" = "$buffers" ] || exit 1

# Explicit commands expand formats; an omitted command uses copy-command.
$TMUX set-option -g @output_file "$OUT" || exit 1
: >"$OUT"
$TMUX send-keys -X pipe-output "cat >#{@output_file}" || exit 1
check_pipe
$TMUX set-option -s copy-command "cat >$OUT" || exit 1
: >"$OUT"
$TMUX send-keys -X pipe-output || exit 1
check_pipe
[ "$($TMUX show-buffer)" = sentinel ] || exit 1

$TMUX send-keys -X select-output || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -X copy-selection || exit 1
[ "$($TMUX show-buffer)" = unfinished ] || exit 1
$TMUX send-keys -X cancel || exit 1

$TMUX copy-mode || exit 1
$TMUX send-keys -X select-output || exit 1
: >"$OUT"
$TMUX send-keys -X pipe-selection "cat >$OUT" || exit 1
check_pipe
[ "$($TMUX show-buffer)" = unfinished ] || exit 1
$TMUX send-keys -X cancel || exit 1

$TMUX copy-mode || exit 1
$TMUX send-keys -X search-backward separator || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -X copy-output || exit 1
[ "$($TMUX show-buffer)" = "$EXPECTED" ] || exit 1
$TMUX send-keys -X cancel || exit 1

$TMUX copy-mode || exit 1
$TMUX send-keys -X search-backward one || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -X copy-output || exit 1
[ "$($TMUX show-buffer)" = "$EXPECTED" ] || exit 1
$TMUX send-keys -X cancel || exit 1

$TMUX new-window -d -n plain "printf 'alpha\\nbeta\\n'; exec sleep 100" || exit 1
sleep 1
$TMUX copy-mode -t :plain || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :plain.0 -X copy-output -a || exit 1
all=$($TMUX show-buffer)
case "$all" in
*alpha*beta*) ;;
*) exit 1 ;;
esac
$TMUX send-keys -t :plain.0 -X cancel || exit 1

# Selecting the entire buffer works with either selection convention.
for keys in emacs vi; do
	$TMUX set-option -w -t :plain mode-keys "$keys" || exit 1
	$TMUX copy-mode -t :plain || exit 1
	$TMUX send-keys -t :plain.0 -X select-output -a || exit 1
	$TMUX set-buffer sentinel || exit 1
	$TMUX send-keys -t :plain.0 -X copy-selection || exit 1
	[ "$($TMUX show-buffer)" = "$(printf 'alpha\nbeta')" ] || exit 1
	$TMUX send-keys -t :plain.0 -X cancel || exit 1
done

$TMUX set-buffer -b keep unchanged || exit 1
$TMUX copy-mode -t :plain || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :plain.0 -X copy-output || exit 1
[ "$($TMUX show-buffer -b keep)" = unchanged ] || exit 1
[ "$($TMUX show-buffer)" = sentinel ] || exit 1
$TMUX send-keys -t :plain.0 -X select-output || exit 1
[ "$($TMUX display-message -p -t :plain.0 '#{selection_present}')" = 0 ] ||
    exit 1

# Whole-buffer pipes also work without OSC 133 markers.
printf 'alpha\nbeta\n' >"$EXP"
height=$($TMUX display-message -p -t :plain.0 '#{pane_height}')
i=3
while [ "$i" -lt "$height" ]; do
	printf '\n' >>"$EXP"
	i=$((i + 1))
done
: >"$OUT"
$TMUX send-keys -t :plain.0 -X pipe-output -a "cat >$OUT" || exit 1
check_pipe
[ "$($TMUX show-buffer)" = sentinel ] || exit 1
: >"$OUT"
$TMUX send-keys -t :plain.0 -X copy-pipe-output -a "cat >$OUT" || exit 1
check_pipe
$TMUX save-buffer "$OUT" || exit 1
cmp "$OUT" "$EXP" || exit 1
$TMUX send-keys -t :plain.0 -X cancel || exit 1

$TMUX new-window -d -n empty "printf '\\033]133;A\\007p\\$ \\033]133;B\\007echo\\033]133;C\\007one\\n\\033]133;D;0\\007\\033]133;A\\007p\\$ \\033]133;B\\007true\\n\\033]133;C\\007\\033]133;D;0\\007'; exec sleep 100" || exit 1
sleep 1
$TMUX copy-mode -t :empty || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :empty.0 -X copy-output || exit 1
[ "$($TMUX show-buffer)" = sentinel ] || exit 1
$TMUX send-keys -t :empty.0 -X select-output || exit 1
[ "$($TMUX display-message -p -t :empty.0 '#{selection_present}')" = 0 ] || exit 1
$TMUX send-keys -t :empty.0 -X cancel || exit 1

$TMUX new-window -d -n emptyprompt "printf '\\033]133;A\\007p\\$ \\033]133;B\\007echo\\033]133;C\\007one\\n\\033]133;D;0\\007\\033]133;A\\007p\\$ \\033]133;B\\007true\\n\\033]133;C\\007\\033]133;D;0\\007\\033]133;A\\007p\\$ \\033]133;B\\007'; exec sleep 100" || exit 1
sleep 1
$TMUX copy-mode -t :emptyprompt || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :emptyprompt.0 -X copy-output || exit 1
[ "$($TMUX show-buffer)" = sentinel ] || exit 1
$TMUX send-keys -t :emptyprompt.0 -X cancel || exit 1

$TMUX new-window -d -n blank "printf '\\033]133;A\\007p\\$ \\033]133;B\\007echo\\n\\033]133;C\\007\\n\\033]133;D;0\\007\\033]133;A\\007p\\$ \\033]133;B\\007'; exec sleep 100" || exit 1
sleep 1
$TMUX copy-mode -t :blank || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :blank.0 -X copy-output || exit 1
[ $($TMUX show-buffer | wc -c) -eq 1 ] || exit 1
$TMUX send-keys -t :blank.0 -X cancel || exit 1

$TMUX new-window -d -n prompt "printf '\\033]133;A\\007p\\$ \\033]133;B\\007echo\\033]133;C\\007one\\n\\033]133;D;0\\007\\033]133;A\\007p\\$ \\033]133;B\\007'; exec sleep 100" || exit 1
sleep 1
$TMUX copy-mode -t :prompt || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :prompt.0 -X copy-output || exit 1
[ "$($TMUX show-buffer)" = one ] || exit 1
$TMUX send-keys -t :prompt.0 -X cancel || exit 1

$TMUX copy-mode -t :prompt || exit 1
$TMUX send-keys -t :prompt.0 -X -N 100 cursor-down || exit 1
$TMUX send-keys -t :prompt.0 C-o || exit 1
[ "$($TMUX display-message -p -t :prompt.0 '#{selection_present}')" = 1 ] || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :prompt.0 -X copy-selection || exit 1
[ "$($TMUX show-buffer)" = one ] || exit 1
$TMUX send-keys -t :prompt.0 -X cancel || exit 1

$TMUX new-window -d -n same "printf '\\033]133;A\\007p\\$ \\033]133;B\\007echo\\n\\033]133;C\\007one\\033]133;D;0\\007\\033]133;A\\007p\\$ \\033]133;B\\007'; exec sleep 100" || exit 1
sleep 1
$TMUX copy-mode -t :same || exit 1
$TMUX send-keys -t :same.0 -X search-backward one || exit 1
$TMUX send-keys -t :same.0 -X select-output || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :same.0 -X copy-selection || exit 1
[ "$($TMUX show-buffer)" = one ] || exit 1
$TMUX send-keys -t :same.0 -X cancel || exit 1

$TMUX new-window -d -n clear "printf 'old1\\nold2\\nold3\\nold4\\nold5\\nold6\\n\\033]133;A\\007p\\$ \\033]133;B\\007echo 1; clear; ps\\n\\033]133;C\\0071\\n\\033[H\\033[2JPID TTY\\n1 pts/0\\n\\033]133;D;0\\007separator\\n\\033]133;A\\007p\\$ \\033]133;B\\007'; exec sleep 100" || exit 1
sleep 1
$TMUX copy-mode -t :clear || exit 1
$TMUX send-keys -t :clear.0 C-o || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :clear.0 -X copy-selection || exit 1
[ "$($TMUX show-buffer)" = "$(printf '1\nPID TTY\n1 pts/0')" ] || exit 1
$TMUX send-keys -t :clear.0 -X cancel || exit 1

$TMUX new-window -d -n oneline "printf '\\033]133;A\\007p\\$ \\033]133;B\\007echo\\n\\033]133;C\\007one\\033]133;D;0\\007\\nseparator\\n\\033]133;A\\007p\\$ \\033]133;B\\007'; exec sleep 100" || exit 1
sleep 1
$TMUX copy-mode -t :oneline || exit 1
$TMUX send-keys -t :oneline.0 -X search-backward echo || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :oneline.0 -X copy-output || exit 1
[ "$($TMUX show-buffer)" = one ] || exit 1
$TMUX send-keys -t :oneline.0 -X cancel || exit 1

$TMUX new-window -d -n nextprompt "printf '\\033]133;A\\007p\\$ \\033]133;B\\007echo\\n\\033]133;C\\007one\\ntwo\\033]133;D;0\\007\\033]133;A\\007p\\$ \\033]133;B\\007'; exec sleep 100" || exit 1
sleep 1
$TMUX copy-mode -t :nextprompt || exit 1
$TMUX send-keys -t :nextprompt.0 -X search-backward echo || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :nextprompt.0 -X copy-output || exit 1
[ "$($TMUX show-buffer)" = "$EXPECTED" ] || exit 1
$TMUX send-keys -t :nextprompt.0 -X cancel || exit 1

$TMUX new-window -d -n hist "printf '\\033]133;A\\007p\\$ \\033]133;B\\007seq\\n\\033]133;C\\007'; seq 1 40; sleep 3; seq 100 103; printf '\\033]133;D;0\\007\\033]133;A\\007p\\$ \\033]133;B\\007'; exec sleep 100" || exit 1
sleep 1
$TMUX clear-history -t :hist.0 || exit 1
sleep 4
$TMUX copy-mode -t :hist || exit 1
$TMUX set-buffer sentinel || exit 1
$TMUX send-keys -t :hist.0 -X copy-output || exit 1
$TMUX show-buffer >$OUT
[ "$(head -n1 "$OUT")" != sentinel ] || exit 1
[ "$(head -n1 "$OUT")" != 1 ] || exit 1
[ "$(tail -n1 "$OUT")" = 103 ] || exit 1
grep -q seq "$OUT" && exit 1
$TMUX send-keys -t :hist.0 -X cancel || exit 1

exit 0
