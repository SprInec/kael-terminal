. ./regress-common.inc

PATH=/bin:/usr/bin
TERM=screen

[ -z "$TEST_TMUX" ] && TEST_TMUX=$(readlink -f ../tmux)
TMUX="$TEST_TMUX -LtestA$$ -f/dev/null"

# Keep panes alive until the next case or cleanup, without reading replies.
INPUT_HOLD='while :; do sleep 3600; done'

TMP=$(mktemp)
EXP=$(mktemp)
trap 'rm -f "$TMP" "$EXP"; stop_server $TMUX || exit 1' 0 1 15

exit_status=0

fail()
{
	echo "FAIL: $1"
	diff -u "$EXP" "$TMP"
	exit_status=1
}

start_pane()
{
	start_pane_hlimit "$1" "$2" "$3" "$4" 0
}

start_pane_history()
{
	start_pane_hlimit "$1" "$2" "$3" "$4" 2000
}

start_pane_hlimit()
{
	name=$1
	sx=$2
	sy=$3
	seq=$4
	hlimit=$5

	# Keep one session while replacing the test session. A new server
	# for every input case is particularly expensive under ASan on macOS.
	if ! $TMUX has-session -t =test-setup 2>/dev/null; then
		$TMUX new-session -d -s test-setup "$INPUT_HOLD" || exit 1
	fi
	if [ -n "$input_session" ]; then
		$TMUX kill-session -t "=$input_session" 2>/dev/null
	fi
	$TMUX set-option -g history-limit "$hlimit" || exit 1
	$TMUX new-session -d -x "$sx" -y "$sy" -s "$name" \
	    "printf '$seq'; printf '\\033]2;input-ready\\007'; $INPUT_HOLD" || exit 1
	input_session=$name
	wait_for_output input-ready $TMUX display-message -p -t "$name:" \
	    '#{pane_title}' || exit 1
}

start_cmd()
{
	name=$1
	sx=$2
	sy=$3
	cmd=$4

	stop_server $TMUX || exit 1
	$TMUX new-session -d -x "$sx" -y "$sy" -s "$name" "$cmd" || exit 1
	input_session=$name
}

normalize_capture()
{
	sed 's/[	 ]*$//' |
	    awk '{ line[NR] = $0; if ($0 != "") last = NR }
	        END { for (i = 1; i <= last; i++) print line[i] }'
}

capture_grid()
{
	$TMUX capture-pane -pN -t "$1:" -S 0 -E - | normalize_capture
}

capture_matches()
{
	capture_grid "$1" >"$TMP" || return 1
	cmp -s "$TMP" "$EXP"
}

check_capture()
{
	name=$1
	expected=$2

	printf "%s\n" "$expected" >"$EXP"
	wait_until capture_matches "$name" || fail "$name"
}

check_cursor()
{
	name=$1
	expected=$2

	actual=$($TMUX display-message -p -t "$name:" '#{cursor_x},#{cursor_y}')
	if [ "$actual" != "$expected" ]; then
		printf "%s\n" "$expected" >"$EXP"
		printf "%s\n" "$actual" >"$TMP"
		fail "$name cursor"
	fi
}

check_flags()
{
	name=$1
	expected=$2

	$TMUX capture-pane -pNF -t "$name:" -S 0 -E - |
	    normalize_capture |
	    awk '$0 != "-"' >"$TMP"
	printf "%s\n" "$expected" >"$EXP"
	cmp "$TMP" "$EXP" || fail "$name flags"
}

check_joined()
{
	name=$1
	expected=$2

	$TMUX capture-pane -pNJ -t "$name:" -S 0 -E - |
	    normalize_capture >"$TMP"
	printf "%s\n" "$expected" >"$EXP"
	cmp "$TMP" "$EXP" || fail "$name joined"
}

capture_raw()
{
	$TMUX capture-pane -pR -t "$1:"
}

capture_raw_used()
{
	capture_raw "$1" |
	    awk '/^(G|	L)/ || /^		C/ && $3 !~ /^data=\(1,1, \)$/'
}

check_raw()
{
	name=$1
	expected=$2

	capture_raw "$name" >"$TMP"
	printf "%s\n" "$expected" >"$EXP"
	cmp "$TMP" "$EXP" || fail "$name raw"
}

check_raw_used()
{
	name=$1
	expected=$2

	capture_raw_used "$name" >"$TMP"
	printf "%s\n" "$expected" >"$EXP"
	cmp "$TMP" "$EXP" || fail "$name raw used"
}

check_raw_has()
{
	name=$1
	shift

	capture_raw "$name" >"$TMP"
	for expected in "$@"; do
		if ! grep -Fqx "$expected" "$TMP"; then
			printf "%s\n" "$expected" >"$EXP"
			fail "$name raw missing"
		fi
	done
}

check_raw_matches()
{
	name=$1
	shift

	capture_raw "$name" >"$TMP"
	for expected in "$@"; do
		if ! grep -Eq "$expected" "$TMP"; then
			printf "%s\n" "$expected" >"$EXP"
			fail "$name raw missing"
		fi
	done
}

check_raw_no_matches()
{
	name=$1
	shift

	capture_raw "$name" >"$TMP"
	for unexpected in "$@"; do
		if grep -Eq "$unexpected" "$TMP"; then
			printf "%s\n" "$unexpected" >"$EXP"
			fail "$name raw unexpected"
		fi
	done
}
