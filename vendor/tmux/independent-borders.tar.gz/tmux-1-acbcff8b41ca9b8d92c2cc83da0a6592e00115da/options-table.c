/* $OpenBSD: options-table.c,v 1.254 2026/10/16 07:59:06 nicm Exp $ */

/*
 * Copyright (c) 2011 Nicholas Marriott <nicholas.marriott@gmail.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF MIND, USE, DATA OR PROFITS, WHETHER
 * IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/types.h>

#include <string.h>

#include "tmux.h"

/*
 * This file has a tables with all the server, session and window
 * options. These tables are the master copy of the options with their real
 * (user-visible) types, range limits and default values. At start these are
 * copied into the runtime global options trees (which only has number and
 * string types). These tables are then used to look up the real type when the
 * user sets an option or its value needs to be shown.
 */

/* Choice option type lists. */
static const char *options_table_mode_keys_list[] = {
	"emacs", "vi", NULL
};
static const char *options_table_clock_mode_style_list[] = {
	"12", "24", "12-with-seconds", "24-with-seconds", NULL
};
static const char *options_table_status_list[] = {
	"off", "on", "2", "3", "4", "5", NULL
};
static const char *options_table_message_line_list[] = {
	"0", "1", "2", "3", "4", NULL
};
static const char *options_table_status_keys_list[] = {
	"emacs", "vi", NULL
};
static const char *options_table_status_justify_list[] = {
	"left", "centre", "right", "absolute-centre", NULL
};
static const char *options_table_status_position_list[] = {
	"top", "bottom", NULL
};
static const char *options_table_side_status_list[] = {
	"off", "left", "right", NULL
};
static const char *options_table_bell_action_list[] = {
	"none", "any", "current", "other", NULL
};
static const char *options_table_visual_bell_list[] = {
	"off", "on", "both", NULL
};
static const char *options_table_cursor_style_list[] = {
	"default", "blinking-block", "block", "blinking-underline", "underline",
	"blinking-bar", "bar", NULL
};
static const char *options_table_pane_scrollbars_list[] = {
	"off", "modal", "on", "auto-hide", NULL
};
static const char *options_table_pane_scrollbars_position_list[] = {
	"right", "left", NULL
};
static const char *options_table_pane_status_list[] = {
	"off", "top", "bottom", "top-floating", "bottom-floating", NULL
};
static const char *options_table_pane_border_indicators_list[] = {
	"off", "colour", "arrows", "both", NULL
};
static const char *options_table_pane_border_lines_list[] = {
	"single", "double", "heavy", "simple", "number", "spaces", "none",
	"rounded", NULL
};
static const char *options_table_pane_border_type_list[] = {
	"joined", "separate", "separate-active", NULL
};
static const char *options_table_menu_border_lines_list[] = {
	"single", "double", "heavy", "simple", "rounded", "padded", "none", NULL
};
static const char *options_table_set_clipboard_list[] = {
	"off", "external", "on", NULL
};
static const char *options_table_get_clipboard_list[] = {
	"off", "buffer", "request", "both", NULL
};
static const char *options_table_window_size_list[] = {
	"largest", "smallest", "manual", "latest", NULL
};
static const char *options_table_remain_on_exit_list[] = {
	"off", "on", "failed", "key", "failed-key", NULL
};
static const char *options_table_destroy_unattached_list[] = {
	"off", "on", "keep-last", "keep-group", NULL
};
static const char *options_table_detach_on_destroy_list[] = {
	"off", "on", "no-detached", "previous", "next", NULL
};
static const char *options_table_extended_keys_list[] = {
	"off", "on", "always", NULL
};
static const char *options_table_extended_keys_format_list[] = {
	"csi-u", "xterm", NULL
};
static const char *options_table_allow_passthrough_list[] = {
	"off", "on", "all", NULL
};
static const char *options_table_theme_list[] = {
	"detect", "terminal", "light", "dark", NULL
};
static const char *options_table_copy_mode_line_numbers_list[] = {
	"off", "default", "absolute", "relative", "hybrid", NULL
};

/* Status line format. */
#define OPTIONS_TABLE_STATUS_FORMAT1 \
	"#[align=left range=left #{E:status-left-style}]" \
	"#[push-default]" \
	"#{T;=/#{status-left-length}:status-left}" \
	"#[pop-default]" \
	"#[norange default]" \
	"#[list=on align=#{status-justify}]" \
	"#[list=left-marker]<#[list=right-marker]>#[list=on]" \
	"#{W:" \
		"#[range=window|#{window_index} " \
			"#{E:window-status-style}" \
			"#{?#{&&:#{window_last_flag}," \
				"#{!=:#{E:window-status-last-style},default}}, " \
				"#{E:window-status-last-style}," \
			"}" \
			"#{?#{&&:#{window_bell_flag}," \
				"#{!=:#{E:window-status-bell-style},default}}, " \
				"#{E:window-status-bell-style}," \
				"#{?#{&&:#{||:#{window_activity_flag}," \
					     "#{window_silence_flag}}," \
					"#{!=:" \
					"#{E:window-status-activity-style}," \
					"default}}, " \
					"#{E:window-status-activity-style}," \
				"}" \
			"}" \
		"]" \
		"#[push-default]" \
		"#{T:window-status-format}" \
		"#[pop-default]" \
		"#[norange default]" \
		"#{?loop_last_flag,,#{E:window-status-separator}}" \
	"," \
		"#[range=window|#{window_index} list=focus " \
			"#{?#{!=:#{E:window-status-current-style},default}," \
				"#{E:window-status-current-style}," \
				"#{E:window-status-style}" \
			"}" \
			"#{?#{&&:#{window_last_flag}," \
				"#{!=:#{E:window-status-last-style},default}}, " \
				"#{E:window-status-last-style}," \
			"}" \
			"#{?#{&&:#{window_bell_flag}," \
				"#{!=:#{E:window-status-bell-style},default}}, " \
				"#{E:window-status-bell-style}," \
				"#{?#{&&:#{||:#{window_activity_flag}," \
					     "#{window_silence_flag}}," \
					"#{!=:" \
					"#{E:window-status-activity-style}," \
					"default}}, " \
					"#{E:window-status-activity-style}," \
				"}" \
			"}" \
		"]" \
		"#[push-default]" \
		"#{T:window-status-current-format}" \
		"#[pop-default]" \
		"#[norange list=on default]" \
		"#{?loop_last_flag,,#{E:window-status-separator}}" \
	"}" \
	"#[nolist align=right range=right #{E:status-right-style}]" \
	"#[push-default]" \
	"#{T;=/#{status-right-length}:status-right}" \
	"#[pop-default]" \
	"#[norange default]"
#define OPTIONS_TABLE_STATUS_FORMAT2 \
	"#[align=left]" \
	"#{R: ,#{e|-:#{w;T;=/#{status-left-length}:status-left},3}}P: " \
	"#[norange default]" \
	"#[list=on align=#{status-justify}]" \
	"#[list=left-marker]<#[list=right-marker]>#[list=on]" \
	"#{P:" \
		"#[range=pane|#{pane_id} " \
			"#{E:pane-status-style}" \
		"]" \
		"#[push-default]" \
		"#{T:window-pane-status-format}" \
		"#[pop-default]" \
		"#[norange list=on default]" \
		"#{?loop_last_flag,,#{E:window-status-separator}}" \
	"," \
		"#[range=pane|#{pane_id} list=focus " \
			"#{?#{!=:#{E:pane-status-current-style},default}," \
				"#{E:pane-status-current-style}," \
				"#{E:pane-status-style}" \
			"}" \
		"]" \
		"#[push-default]" \
		"#{T:window-pane-current-status-format}" \
		"#[pop-default]" \
		"#[norange list=on default]" \
		"#{?loop_last_flag,,#{E:window-status-separator}}" \
	"}"
#define OPTIONS_TABLE_STATUS_FORMAT3 \
	"#[align=left]" \
	"#{R: ,#{e|-:#{w;T;=/#{status-left-length}:status-left},3}}S: " \
	"#[norange default]" \
	"#[list=on align=#{status-justify}]" \
	"#[list=left-marker]<#[list=right-marker]>#[list=on]" \
	"#{S:" \
		"#[range=session|#{session_id} " \
			"#{E:session-status-style}" \
		"]" \
		"#[push-default]" \
		"#S#{q/h:session_alert}" \
		"#[pop-default]" \
		"#[norange list=on default]  " \
	"," \
		"#[range=session|#{session_id} list=focus " \
			"#{?#{!=:#{E:session-status-current-style},default}," \
					"#{E:session-status-current-style}," \
					"#{E:session-status-style}" \
			"}" \
		"]" \
		"#[push-default]" \
		"#S*#{q/h:session_alert}" \
		"#[pop-default]" \
		"#[norange list=on default] " \
	"}"
static const char *options_table_status_format_default[] = {
	OPTIONS_TABLE_STATUS_FORMAT1,
	OPTIONS_TABLE_STATUS_FORMAT2,
	OPTIONS_TABLE_STATUS_FORMAT3,
	NULL
};

/* Side status line format. */
#define OPTIONS_TABLE_SIDE_STATUS_WINDOW \
	"#[range=window|#{window_index} #{E:window-status-style}]" \
	"#I:#W#{?window_flags,#{window_flags}, }" \
	"#[norange default]#[nl]"
#define OPTIONS_TABLE_SIDE_STATUS_CURRENT \
	"#[range=window|#{window_index} list=focus " \
		"#{?#{!=:#{E:window-status-current-style},default}," \
			"#{E:window-status-current-style}," \
			"#{E:window-status-style}" \
		"}" \
	"]" \
	"#I:#W#{?window_flags,#{window_flags}, }" \
	"#[norange list=on default]#[nl]"
#define OPTIONS_TABLE_SIDE_STATUS_BRANCH \
	"#[acs fg=themelightgrey]#{?window_end_flag,mq,tq}+" \
	"#[noacs default] "
#define OPTIONS_TABLE_SIDE_STATUS_FORMAT1 \
	"#[list=on]" \
	"#[list=left-marker]#[acs]-#[noacs]#[nl]" \
	"#[list=right-marker]#[acs].#[noacs]#[nl]" \
	"#{?#{e|>:#{server_sessions},1}," \
		"#{S:" \
			"#[range=session|#{session_id}]" \
			"#{session_name}" \
			"#[norange]#[nl]" \
			"#{?#{==:#{session_name},#{client_session}}," \
				"#{W:" \
					OPTIONS_TABLE_SIDE_STATUS_BRANCH \
					OPTIONS_TABLE_SIDE_STATUS_WINDOW \
				"," \
					OPTIONS_TABLE_SIDE_STATUS_BRANCH \
					OPTIONS_TABLE_SIDE_STATUS_CURRENT \
				"}" \
			",}" \
		"}" \
	"," \
		"#{W:" \
			OPTIONS_TABLE_SIDE_STATUS_WINDOW \
		"," \
			OPTIONS_TABLE_SIDE_STATUS_CURRENT \
		"}" \
	"}"

/* Helpers for hook options. */
#define OPTIONS_TABLE_HOOK(hook_name, default_value, hook_text) \
	{ .name = hook_name, \
	  .type = OPTIONS_TABLE_COMMAND, \
	  .scope = OPTIONS_TABLE_SESSION, \
	  .flags = OPTIONS_TABLE_IS_ARRAY|OPTIONS_TABLE_IS_HOOK, \
	  .default_str = default_value,	\
	  .separator = "", \
	  .text = hook_text \
	}

#define OPTIONS_TABLE_PANE_HOOK(hook_name, default_value, hook_text) \
	{ .name = hook_name, \
	  .type = OPTIONS_TABLE_COMMAND, \
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE, \
	  .flags = OPTIONS_TABLE_IS_ARRAY|OPTIONS_TABLE_IS_HOOK, \
	  .default_str = default_value,	\
	  .separator = "", \
	  .text = hook_text \
	}

#define OPTIONS_TABLE_WINDOW_HOOK(hook_name, default_value, hook_text) \
	{ .name = hook_name, \
	  .type = OPTIONS_TABLE_COMMAND, \
	  .scope = OPTIONS_TABLE_WINDOW, \
	  .flags = OPTIONS_TABLE_IS_ARRAY|OPTIONS_TABLE_IS_HOOK, \
	  .default_str = default_value,	\
	  .separator = "", \
	  .text = hook_text \
	}

#define OPTIONS_TABLE_AFTER_HOOK(command_name) \
	OPTIONS_TABLE_HOOK("after-" command_name, "", \
	    "Run after the " command_name " command completes.")

/* Map of name conversions. */
const struct options_name_map options_other_names[] = {
	{ "display-panes-color", "display-panes-colour" },
	{ "display-panes-active-color", "display-panes-active-colour" },
	{ "clock-mode-color", "clock-mode-colour" },
	{ "cursor-color", "cursor-colour" },
	{ "prompt-cursor-color", "prompt-cursor-colour" },
	{ "prompt-command-cursor-color", "prompt-command-cursor-colour" },
	{ "pane-colors", "pane-colours" },
	{ NULL, NULL }
};

/* Top-level options. */
const struct options_table_entry options_table[] = {
	/* Server options. */
	{ .name = "backspace",
	  .type = OPTIONS_TABLE_KEY,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_num = '\177',
	  .text = "The key to send for backspace."
	},

	{ .name = "buffer-limit",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SERVER,
	  .minimum = 1,
	  .maximum = INT_MAX,
	  .default_num = 50,
	  .text = "The maximum number of automatic buffers. "
		  "When this is reached, the oldest buffer is deleted."
	},

	{ .name = "clear-on-attach",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_num = 1,
	  .text = "Whether to use the alternate screen and clear it when "
		  "a client is attached. When disabled, tmux does not "
		  "enter the alternate screen on attach so terminal "
		  "content before tmux remains in scrollback."
	},

	{ .name = "command-alias",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_ARRAY,
	  .default_str = "split-pane=split-window,"
			 "splitp=split-window,"
			 "server-info=show-messages -JT,"
			 "info=show-messages -JT,"
			 "choose-window=choose-tree -w,"
			 "choose-session=choose-tree -s,"
			 "help=list-commands -h",
	  .separator = ",",
	  .text = "Array of command aliases. "
		  "Each entry is an alias and a command separated by '='."
	},

	{ .name = "codepoint-widths",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_ARRAY,
	  .default_str = "",
	  .separator = ",",
	  .text = "Array of override widths for Unicode codepoints."
	},

	{ .name = "copy-command",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_str = "",
	  .text = "Shell command run when text is copied. "
		  "If empty, no command is run."
	},

	{ .name = "cursor-colour",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "",
	  .text = "Colour of the cursor."
	},

	{ .name = "cursor-style",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .choices = options_table_cursor_style_list,
	  .default_num = 0,
	  .text = "Style of the cursor."
	},

	{ .name = "default-client-command",
	  .type = OPTIONS_TABLE_COMMAND,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_str = "new-session",
	  .text = "Default command to run when tmux is run without a command."
	},

	{ .name = "default-terminal",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_str = TMUX_TERM,
	  .text = "Default for the 'TERM' environment variable."
	},

	{ .name = "editor",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_str = _PATH_VI,
	  .text = "Editor run to edit files."
	},

	{ .name = "escape-time",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SERVER,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 10,
	  .unit = "milliseconds",
	  .text = "Time to wait before assuming a key is Escape."
	},

	{ .name = "exit-empty",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_num = 1,
	  .text = "Whether the server should exit if there are no sessions."
	},

	{ .name = "exit-unattached",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_num = 0,
	  .text = "Whether the server should exit if there are no attached "
		  "clients."
	},

	{ .name = "extended-keys",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SERVER,
	  .choices = options_table_extended_keys_list,
	  .default_num = 0,
	  .text = "Whether to request extended key sequences from terminals "
		  "that support it."
	},

	{ .name = "extended-keys-format",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SERVER,
	  .choices = options_table_extended_keys_format_list,
	  .default_num = 1,
	  .text = "The format of emitted extended key sequences."
	},

	{ .name = "focus-events",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_num = 0,
	  .text = "Whether to send focus events to applications."
	},

	{ .name = "get-clipboard",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SERVER,
	  .choices = options_table_get_clipboard_list,
	  .default_num = 1,
	  .text = "When an application requests the clipboard, whether to "
		  "ignore the request ('off'); respond with the newest buffer "
		  "('buffer'); request the clipboard from the most recently "
		  "used terminal ('request'); or to request the clipboard, "
		  "create a buffer, and send it to the application ('both')."
	},

	{ .name = "history-file",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_str = "",
	  .text = "Location of the command prompt history file. "
		  "Empty does not write a history file."
	},

#ifdef ENABLE_IMAGES
	{ .name = "image-size-limit",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SERVER,
	  .minimum = 1,
	  .maximum = UINT_MAX,
	  .default_num = 64 * 1024 * 1024,
	  .unit = "bytes",
	  .text = "Maximum size of an uploaded or decoded image."
	},

	{ .name = "image-total-count-limit",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SERVER,
	  .minimum = 1,
	  .maximum = INT_MAX,
	  .default_num = 1000,
	  .text = "Maximum number of stored images."
	},

	{ .name = "image-total-size-limit",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SERVER,
	  .minimum = 1,
	  .maximum = UINT_MAX,
	  .default_num = 1024 * 1024 * 1024,
	  .unit = "bytes",
	  .text = "Maximum total image pixel memory."
	},
#endif

	{ .name = "input-buffer-size",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SERVER,
	  .minimum = INPUT_BUF_DEFAULT_SIZE,
	  .maximum = UINT_MAX,
	  .default_num = INPUT_BUF_DEFAULT_SIZE,
	  .text = "Number of bytes accepted in a single input before dropping."
	},

	{ .name = "menu-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .default_str = "bg=themedarkgrey,fg=themewhite",
	  .separator = ",",
	  .text = "Default style of menu."
	},

	{ .name = "menu-selected-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .default_str = "bg=themeyellow,fg=themeblack",
	  .separator = ",",
	  .text = "Default style of selected menu item."
	},

	{ .name = "menu-border-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "bg=themedarkgrey,fg=themelightgrey",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Default style of menu borders."
	},

	{ .name = "menu-border-lines",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .choices = options_table_menu_border_lines_list,
	  .default_num = BOX_LINES_SINGLE,
	  .text = "Type of characters used to draw menu border lines. Some of "
		  "these are only supported on terminals with UTF-8 support."
	},

	{ .name = "message-limit",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SERVER,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 1000,
	  .text = "Maximum number of server messages to keep."
	},

	{ .name = "prefix-timeout",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SERVER,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 0,
	  .unit = "milliseconds",
	  .text = "The timeout for the prefix key if no subsequent key is "
		  "pressed. Zero means disabled."
	},

	{ .name = "prompt-history-limit",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SERVER,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 100,
	  .text = "Maximum number of commands to keep in history."
	},

	{ .name = "set-clipboard",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SERVER,
	  .choices = options_table_set_clipboard_list,
	  .default_num = 1,
	  .text = "Whether to attempt to set the system clipboard ('on' or "
		  "'external') and whether to allow applications to create "
		  "paste buffers with an escape sequence ('on' only)."
	},

	{ .name = "terminal-overrides",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_ARRAY,
	  .default_str = "linux*:AX@",
	  .separator = ",",
	  .text = "List of terminal capabilities overrides."
	},

	{ .name = "terminal-features",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_ARRAY,
	  .default_str = "xterm*:clipboard:ccolour:cstyle:focus:title,"
			 "screen*:title,"
			 "rxvt*:ignorefkeys",
	  .separator = ",",
	  .text = "List of terminal features, used if they cannot be "
		  "automatically detected."
	},

	{ .name = "theme",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SERVER,
	  .choices = options_table_theme_list,
	  .default_num = 0,
	  .text = "Whether tmux should detect the terminal theme, use terminal "
		  "ANSI colours, or force the light or dark theme."
	},

	{ .name = "dark-theme-black",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},gray5,black}",
	  .text = "Dark theme colour for black."
	},

	{ .name = "dark-theme-white",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},gray90,white}",
	  .text = "Dark theme colour for white."
	},

	{ .name = "dark-theme-light-grey",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},gray70,white}",
	  .text = "Dark theme colour for light grey."
	},

	{ .name = "dark-theme-dark-grey",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},gray15,black}",
	  .text = "Dark theme colour for dark grey."
	},

	{ .name = "dark-theme-green",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},yellowgreen,green}",
	  .text = "Dark theme colour for green."
	},

	{ .name = "dark-theme-yellow",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},darkgoldenrod,yellow}",
	  .text = "Dark theme colour for yellow."
	},

	{ .name = "dark-theme-red",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},indianred,red}",
	  .text = "Dark theme colour for red."
	},

	{ .name = "dark-theme-blue",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},skyblue3,blue}",
	  .text = "Dark theme colour for blue."
	},

	{ .name = "dark-theme-cyan",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},cadetblue,cyan}",
	  .text = "Dark theme colour for cyan."
	},

	{ .name = "dark-theme-magenta",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},mediumpurple,magenta}",
	  .text = "Dark theme colour for magenta."
	},

	{ .name = "light-theme-black",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},gray95,black}",
	  .text = "Light theme colour for black."
	},

	{ .name = "light-theme-white",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},gray10,white}",
	  .text = "Light theme colour for white."
	},

	{ .name = "light-theme-light-grey",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},gray80,white}",
	  .text = "Light theme colour for light grey."
	},

	{ .name = "light-theme-dark-grey",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},gray45,black}",
	  .text = "Light theme colour for dark grey."
	},

	{ .name = "light-theme-green",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},seagreen,green}",
	  .text = "Light theme colour for green."
	},

	{ .name = "light-theme-yellow",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},darkgoldenrod,yellow}",
	  .text = "Light theme colour for yellow."
	},

	{ .name = "light-theme-red",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},indianred4,red}",
	  .text = "Light theme colour for red."
	},

	{ .name = "light-theme-blue",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},steelblue,blue}",
	  .text = "Light theme colour for blue."
	},

	{ .name = "light-theme-cyan",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},darkcyan,cyan}",
	  .text = "Light theme colour for cyan."
	},

	{ .name = "light-theme-magenta",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "#{?#{e|>=:#{client_colours},256},purple4,magenta}",
	  .text = "Light theme colour for magenta."
	},

	{ .name = "user-keys",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SERVER,
	  .flags = OPTIONS_TABLE_IS_ARRAY,
	  .default_str = "",
	  .separator = ",",
	  .text = "User key assignments. "
		  "Each sequence in the list is translated into a key: "
		  "'User0', 'User1' and so on."
	},

#ifdef HAVE_UTEMPTER
	{ .name = "utmp",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_num = 1,
	  .text = "Whether to maintain utmp records."
	},
#endif

	{ .name = "variation-selector-always-wide",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_SERVER,
	  .default_num = 1,
	  .text = "If the Unicode VS16 codepoint should always be treated as a "
		  "wide character."
	},

	/* Session options. */
	{ .name = "activity-action",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_bell_action_list,
	  .default_num = ALERT_OTHER,
	  .text = "Action to take on an activity alert."
	},

	{ .name = "assume-paste-time",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SESSION,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 1,
	  .unit = "milliseconds",
	  .text = "Maximum time between input to assume it is pasting rather "
		  "than typing."
	},

	{ .name = "base-index",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SESSION,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 0,
	  .text = "Default index of the first window in each session."
	},

	{ .name = "bell-action",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_bell_action_list,
	  .default_num = ALERT_ANY,
	  .text = "Action to take on a bell alert."
	},

	{ .name = "default-command",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "",
	  .text = "Default command to run in new panes. If empty, a shell is "
		  "started."
	},

	{ .name = "default-shell",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = _PATH_BSHELL,
	  .text = "Location of default shell."
	},

	{ .name = "default-size",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .pattern = "[0-9]*x[0-9]*",
	  .default_str = "80x24",
	  .text = "Initial size of new sessions."
	},

	{ .name = "destroy-unattached",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_destroy_unattached_list,
	  .default_num = 0,
	  .text = "Whether to destroy sessions when they have no attached "
		  "clients, or keep the last session whether in the group."
	},

	{ .name = "detach-on-destroy",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_detach_on_destroy_list,
	  .default_num = 1,
	  .text = "Whether to detach when a session is destroyed, or switch "
		  "the client to another session if any exist."
	},

	{ .name = "display-time",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SESSION,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 750,
	  .unit = "milliseconds",
	  .text = "Time for which status line messages should appear."
	},

	{ .name = "focus-follows-mouse",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_num = 0,
	  .text = "Whether moving the mouse into a pane selects it."
	},

	{ .name = "history-limit",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SESSION,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 2000,
	  .unit = "lines",
	  .text = "Maximum number of lines to keep in the history for each "
		  "pane. "
		  "If changed, the new value applies only to new panes."
	},

	{ .name = "initial-repeat-time",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SESSION,
	  .minimum = 0,
	  .maximum = 2000000,
	  .default_num = 0,
	  .unit = "milliseconds",
	  .text = "Time to wait for a key binding to repeat the first time the "
		  "key is pressed, if it is bound with the '-r' flag. "
		  "Subsequent presses use the 'repeat-time' option."
	},

	{ .name = "key-table",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "root",
	  .text = "Default key table. "
		  "Key presses are first looked up in this table."
	},

	{ .name = "lock-after-time",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SESSION,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 0,
	  .unit = "seconds",
	  .text = "Time after which a client is locked if not used."
	},

	{ .name = "lock-command",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = TMUX_LOCK_CMD,
	  .text = "Shell command to run to lock a client."
	},

	{ .name = "message-command-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "bg=themeblack,fg=themeyellow,"
			 "#{?#{m/r:(^|#,)IS(PANE|MODE)($|#,),#{prompt_flags}},,"
			 "fill=themeblack}",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the command prompt when in command mode, if "
		  "'status-keys' is set to 'vi'."
	},

	{ .name = "message-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "#[#{?#{command_prompt},"
		  "#{E:message-command-style},"
		  "#{E:message-style}}]"
		  "#{message}",
	  .text = "Format string for the prompt and message area. "
		  "The '#{message}' placeholder is replaced with the content."
	},

	{ .name = "message-line",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_message_line_list,
	  .default_num = 0,
	  .text = "Position (line) of messages and the command prompt."
	},

	{ .name = "message-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "bg=themeyellow,fg=themeblack,"
			 "#{?#{m/r:(^|#,)IS(PANE|MODE)($|#,),#{prompt_flags}},,"
			 "fill=themeyellow}",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of messages and the command prompt. "
		  "A 'fill' attribute controls background clearing and "
		  "a 'width' attribute (fixed or percentage) constrains "
		  "the prompt area width."
	},

	{ .name = "mouse",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_num = TMUX_MOUSE,
	  .text = "Whether the mouse is recognised and mouse key bindings are "
		  "executed. "
		  "Applications inside panes can use the mouse even when 'off'."
	},

	{ .name = "prefix",
	  .type = OPTIONS_TABLE_KEY,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_num = 'b'|KEYC_CTRL,
	  .text = "The prefix key."
	},

	{ .name = "prefix2",
	  .type = OPTIONS_TABLE_KEY,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_num = KEYC_NONE,
	  .text = "A second prefix key."
	},

	{ .name = "renumber-windows",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_num = 0,
	  .text = "Whether windows are automatically renumbered rather than "
		  "leaving gaps."
	},

	{ .name = "repeat-time",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SESSION,
	  .minimum = 0,
	  .maximum = 2000000,
	  .default_num = 500,
	  .unit = "milliseconds",
	  .text = "Time to wait for a key binding to repeat, if it is bound "
		  "with the '-r' flag."
	},

	{ .name = "set-titles",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_num = 0,
	  .text = "Whether to set the terminal title, if supported."
	},

	{ .name = "set-titles-string",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "#S:#I:#W - \"#T\" #{session_alerts}",
	  .text = "Format of the terminal title to set."
	},

	{ .name = "side-status",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_side_status_list,
	  .default_num = 0,
	  .text = "Whether to draw a vertical status line at the left or "
		  "right of the terminal."
	},

	{ .name = "side-status-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = OPTIONS_TABLE_SIDE_STATUS_FORMAT1,
	  .text = "Format for the side status line."
	},

	{ .name = "side-status-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "fg=themegreen",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the side status line."
	},

	{ .name = "side-status-width",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SESSION,
	  .minimum = 1,
	  .maximum = SHRT_MAX,
	  .default_num = 14,
	  .text = "Width of the side status line."
	},

	{ .name = "silence-action",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_bell_action_list,
	  .default_num = ALERT_OTHER,
	  .text = "Action to take on a silence alert."
	},

	{ .name = "status",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_status_list,
	  .default_num = 1,
	  .text = "Number of lines in the status line."
	},

	{ .name = "status-bg",
	  .type = OPTIONS_TABLE_COLOUR,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_num = 8,
	  .text = "Background colour of the status line. This option is "
		  "deprecated, use 'status-style' instead."
	},

	{ .name = "status-fg",
	  .type = OPTIONS_TABLE_COLOUR,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_num = 8,
	  .text = "Foreground colour of the status line. This option is "
		  "deprecated, use 'status-style' instead."
	},

	{ .name = "status-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .flags = OPTIONS_TABLE_IS_ARRAY,
	  .default_arr = options_table_status_format_default,
	  .text = "Formats for the status lines. "
		  "Each array member is the format for one status line. "
		  "The default status line is made up of several components "
		  "which may be configured individually with other options such "
		  "as 'status-left'."
	},

	{ .name = "status-interval",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SESSION,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 15,
	  .unit = "seconds",
	  .text = "Number of seconds between status line updates."
	},

	{ .name = "status-justify",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_status_justify_list,
	  .default_num = 0,
	  .text = "Position of the window list in the status line."
	},

	{ .name = "status-keys",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_status_keys_list,
	  .default_num = MODEKEY_EMACS,
	  .text = "Key set to use at the command prompt."
	},

	{ .name = "status-left",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "[#{session_name}] ",
	  .text = "Contents of the left side of the status line."
	},

	{ .name = "status-left-length",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SESSION,
	  .minimum = 0,
	  .maximum = SHRT_MAX,
	  .default_num = 10,
	  .text = "Maximum width of the left side of the status line."
	},

	{ .name = "status-left-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "default",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the left side of the status line."
	},

	{ .name = "status-position",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_status_position_list,
	  .default_num = 1,
	  .text = "Position of the status line."
	},

	{ .name = "status-right",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "#{?window_bigger,"
			 "[#{window_offset_x}#,#{window_offset_y}] ,}"
			 "\"#{=21:pane_title}\" %H:%M %d-%b-%y",
	  .text = "Contents of the right side of the status line."

	},

	{ .name = "status-right-length",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_SESSION,
	  .minimum = 0,
	  .maximum = SHRT_MAX,
	  .default_num = 40,
	  .text = "Maximum width of the right side of the status line."
	},

	{ .name = "status-right-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "default",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the right side of the status line."
	},

	{ .name = "status-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .default_str = "bg=themegreen,fg=themeblack",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the status line."
	},

	{ .name = "pane-status-current-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "underscore",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the current pane in the status line."
	},

	{ .name = "pane-status-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "default",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of panes in the status line, except the current "
		  "pane."
	},

	{ .name = "prompt-cursor-colour",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "",
	  .text = "Colour of the cursor when in the command prompt."
	},

	{ .name = "prompt-command-cursor-colour",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "",
	  .text = "Colour of the cursor in the command prompt when in command "
		  "mode, if 'status-keys' is set to 'vi'."
	},

	{ .name = "prompt-cursor-style",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_cursor_style_list,
	  .default_num = 0,
	  .text = "Style of the cursor when in the command prompt."
	},

	{ .name = "prompt-command-cursor-style",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_cursor_style_list,
	  .default_num = 0,
	  .text = "Style of the cursor in the command prompt when in command "
		  "mode, if 'status-keys' is set to 'vi'."
	},

	{ .name = "session-status-current-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "underscore",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the current session in the status line."
	},

	{ .name = "session-status-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "default",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of sessions in the status line, except the current "
		  "session."
	},

	{ .name = "update-environment",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  .flags = OPTIONS_TABLE_IS_ARRAY,
	  .default_str = "DISPLAY KRB5CCNAME MSYSTEM SSH_ASKPASS SSH_AUTH_SOCK "
			 "SSH_AGENT_PID SSH_CONNECTION WAYLAND_DISPLAY "
			 "WINDOWID XAUTHORITY XDG_CURRENT_DESKTOP "
			 "XDG_SESSION_DESKTOP XDG_SESSION_TYPE",
	  .text = "List of environment variables to update in the session "
		  "environment when a client is attached."
	},

	{ .name = "visual-activity",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_visual_bell_list,
	  .default_num = VISUAL_OFF,
	  .text = "How activity alerts should be shown: a message ('on'), "
		  "a message and a bell ('both') or nothing ('off')."
	},

	{ .name = "visual-bell",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_visual_bell_list,
	  .default_num = VISUAL_OFF,
	  .text = "How bell alerts should be shown: a message ('on'), "
		  "a message and a bell ('both') or nothing ('off')."
	},

	{ .name = "visual-silence",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_SESSION,
	  .choices = options_table_visual_bell_list,
	  .default_num = VISUAL_OFF,
	  .text = "How silence alerts should be shown: a message ('on'), "
		  "a message and a bell ('both') or nothing ('off')."
	},

	{ .name = "word-separators",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_SESSION,
	  /*
	   * The set of non-alphanumeric printable ASCII characters minus the
	   * underscore.
	   */
	  .default_str = "!\"#$%&'()*+,-./:;<=>?@[\\]^`{|}~",
	  .text = "Characters considered to separate words; a space matches "
		  "any character with the Unicode White_Space property."
	},

	/* Window options. */
	{ .name = "aggressive-resize",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_num = 0,
	  .text = "When 'window-size' is 'smallest', whether the maximum size "
		  "of a window is the smallest attached session where it is "
		  "the current window ('on') or the smallest session it is "
		  "linked to ('off')."
	},

	{ .name = "allow-passthrough",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .choices = options_table_allow_passthrough_list,
	  .default_num = 0,
	  .text = "Whether applications are allowed to use the escape sequence "
		  "to bypass tmux. Can be 'off' (disallowed), 'on' (allowed "
		  "if the pane is visible), or 'all' (allowed even if the pane "
		  "is invisible)."
	},

	{ .name = "allow-rename",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_num = 0,
	  .text = "Whether applications are allowed to use the escape sequence "
		  "to rename windows."
	},

	{ .name = "allow-set-title",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_num = 1,
	  .text = "Whether applications are allowed to use the escape sequence "
		  "to set the pane title."
	},

	{ .name = "alternate-screen",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_num = 1,
	  .text = "Whether applications are allowed to use the alternate "
		  "screen."
	},

	{ .name = "automatic-rename",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_num = 1,
	  .text = "Whether windows are automatically renamed."
	},

	{ .name = "automatic-rename-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "#{?pane_in_mode,[tmux],#{pane_current_command}}"
			 "#{?pane_dead,[dead],}",
	  .text = "Format used to automatically rename windows."
	},

	{ .name = "clock-mode-colour",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "themeblue",
	  .text = "Colour of the clock in clock mode."
	},

	{ .name = "clock-mode-style",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .choices = options_table_clock_mode_style_list,
	  .default_num = 1,
	  .text = "Time format of the clock in clock mode."
	},

	{ .name = "display-panes-active-colour",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "themered",
	  .text = "Colour of the active pane for 'display-panes'."
	},

	{ .name = "display-panes-border-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "bg=themedarkgrey,fg=themelightgrey",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the pane borders in 'display-panes'."
	},

	{ .name = "display-panes-colour",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .flags = OPTIONS_TABLE_IS_COLOUR,
	  .default_str = "themeblue",
	  .text = "Colour of not active panes for 'display-panes'."
	},

	{ .name = "display-panes-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "#[align=right]"
	                 "#{pane_unzoomed_width}x#{pane_unzoomed_height}",
	  .text = "Format of text shown by 'display-panes', expanded for each "
		  "pane."
	},

	{ .name = "display-panes-time",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .minimum = 1,
	  .maximum = INT_MAX,
	  .default_num = 1000,
	  .unit = "milliseconds",
	  .text = "Time for which 'display-panes' should show pane numbers."
	},

	{ .name = "copy-mode-match-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "bg=themecyan,fg=themeblack",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of search matches in copy mode."
	},

	{ .name = "copy-mode-current-match-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "bg=thememagenta,fg=themeblack",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the current search match in copy mode."
	},

	{ .name = "copy-mode-mark-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "bg=themeyellow,fg=themeblack",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the marked line in copy mode."
	},

	{ .name = "copy-mode-position-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_str = "#[align=right]"
			 "#{t/p:top_line_time}#{?#{e|>:#{top_line_time},0}, ,}"
			 "[#{copy_position}/#{copy_position_limit}]"
			 "#{?search_timed_out, (timed out),"
			 "#{?search_count_present, ("
			 "#{?#{==:#{search_count},0},0 matches,"
			 "#{?search_count_partial,#{search_count}+ matches,"
			 "#{?#{==:#{search_count},1},1 of 1 match,"
			 "#{?search_count_current,#{search_count_current} of "
			 "#{search_count} matches,#{search_count} matches}}}}),}}",
	  .text = "Format of the position indicator in copy mode."
	},

	{ .name = "copy-mode-position-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "#{E:mode-style}",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of position indicator in copy mode."
	},

	{ .name = "copy-mode-selection-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "#{E:mode-style}",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of selection in copy mode."
	},

	{ .name = "copy-mode-current-line-number-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "fg=themeyellow",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of current line number in copy mode."
	},

	{ .name = "copy-mode-current-line-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "default",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the line containing the cursor in copy mode."
	},

	{ .name = "copy-mode-line-number-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "fg=themelightgrey,dim",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of line numbers in copy mode."
	},

	{ .name = "copy-mode-line-numbers",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .choices = options_table_copy_mode_line_numbers_list,
	  .default_num = 0,
	  .text = "Line number mode in copy mode."
	},

	{ .name = "fill-character",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "#{?is_inside,#[bg=themedarkgrey] ,#[fg=themelightgrey]#[acs]~}",
	  .text = "Format used to fill unused parts of window."
	},

	{ .name = "main-pane-height",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "24",
	  .text = "Height of the main pane in the 'main-horizontal' layout. "
		  "This may be a percentage, for example '10%'."
	},

	{ .name = "main-pane-width",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "80",
	  .text = "Width of the main pane in the 'main-vertical' layout. "
		  "This may be a percentage, for example '10%'."
	},

	{ .name = "mode-keys",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .choices = options_table_mode_keys_list,
	  .default_num = MODEKEY_EMACS,
	  .text = "Key set used in copy mode."
	},

	{ .name = "mode-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .default_str = "noattr,bg=themeyellow,fg=themeblack",
	  .separator = ",",
	  .text = "Style of indicators and highlighting in modes."
	},

	{ .name = "monitor-activity",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_num = 0,
	  .text = "Whether an alert is triggered by activity."
	},

	{ .name = "monitor-bell",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_num = 1,
	  .text = "Whether an alert is triggered by a bell."
	},

	{ .name = "monitor-silence",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 0,
	  .text = "Time after which an alert is triggered by silence. "
		  "Zero means no alert."

	},

	{ .name = "other-pane-height",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "0",
	  .text = "Height of the other panes in the 'main-horizontal' layout. "
		  "This may be a percentage, for example '10%'."
	},

	{ .name = "other-pane-width",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "0",
	  .text = "Height of the other panes in the 'main-vertical' layout. "
		  "This may be a percentage, for example '10%'."
	},

	{ .name = "pane-active-border-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_str = "fg=#{?pane_modal_flag,themeblue,"
			 "#{?pane_marked,thememagenta,"
			 "#{?synchronize-panes,themered,"
			 "#{?pane_in_mode,themeyellow,themegreen}}}}",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the active pane border."
	},

	{ .name = "pane-base-index",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .minimum = 0,
	  .maximum = USHRT_MAX,
	  .default_num = 0,
	  .text = "Index of the first pane in each window."
	},

	{ .name = "pane-border-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_str = "#{?pane_active,#[reverse],}#{pane_index}#[default] "
			 "\"#{pane_title}\""
			 "#{?#{mouse},"
				"#[align=right]"
				"#[range=control|7]["
					"#{?#{pane_floating_flag},t,f}"
				"]#[norange]"
				"#[range=control|8]["
					"#{?#{window_zoomed_flag},u,z}"
				"]#[norange]"
				"#[range=control|9][x]#[norange]"
			",}",
	  .text = "Format of text in the pane status lines."
	},

	{ .name = "pane-border-indicators",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .choices = options_table_pane_border_indicators_list,
	  .default_num = PANE_BORDER_COLOUR,
	  .text = "Whether to indicate the active pane by colouring border or "
		  "displaying arrow markers."
	},

	{ .name = "pane-border-lines",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .choices = options_table_pane_border_lines_list,
	  .default_num = PANE_LINES_SINGLE,
	  .text = "Type of characters used to draw pane border lines. Some of "
		  "these are only supported on terminals with UTF-8 support."
	},

	{ .name = "pane-border-status",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .choices = options_table_pane_status_list,
	  .default_num = PANE_STATUS_OFF,
	  .text = "Position of the pane status lines."
	},

	{ .name = "pane-border-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_str = "fg=themelightgrey",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the pane status lines."
	},

	{ .name = "pane-border-type",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .choices = options_table_pane_border_type_list,
	  .default_num = PANE_BORDER_TYPE_JOINED,
	  .text = "How pane borders are drawn: 'joined' shares borders "
		  "between adjacent panes, 'separate' draws a full border "
		  "around each pane, 'separate-active' uses the same layout "
		  "but only draws the border around the active pane."
	},

	{ .name = "pane-colours",
	  .type = OPTIONS_TABLE_COLOUR,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_str = "",
	  .flags = OPTIONS_TABLE_IS_ARRAY,
	  .text = "The default colour palette for colours zero to 255."
	},

	{ .name = "pane-scrollbars",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .choices = options_table_pane_scrollbars_list,
	  .default_num = PANE_SCROLLBARS_OFF,
	  .text = "Pane scrollbar state: off, on, modal, or auto-hide."
	},

	{ .name = "pane-scrollbars-timeout",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .minimum = 0,
	  .maximum = INT_MAX,
	  .default_num = 500,
	  .unit = "milliseconds",
	  .text = "Time before modal and auto-hide pane scrollbars disappear."
	},

	{ .name = "pane-scrollbars-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_str = "bg=themedarkgrey,fg=themelightgrey,width=1,pad=0",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the pane scrollbar."
	},

	{ .name = "pane-scrollbars-position",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .choices = options_table_pane_scrollbars_position_list,
	  .default_num = PANE_SCROLLBARS_RIGHT,
	  .text = "Pane scrollbar position."
	},

	{ .name = "remain-on-exit",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .choices = options_table_remain_on_exit_list,
	  .default_num = 0,
	  .text = "Whether panes should remain ('on'), remain until a key is "
		  "pressed after any exit ('key') or after a failure "
		  "('failed-key'), or be automatically killed ('off' or "
		  "'failed') when the program inside exits."
	},

	{ .name = "remain-on-exit-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_str = "Pane is dead ("
			 "#{?#{!=:#{pane_dead_status},},"
			 "status #{pane_dead_status},}"
			 "#{?#{!=:#{pane_dead_signal},},"
			 "signal #{pane_dead_signal},}, "
			 "#{t:pane_dead_time})",
	  .text = "Message shown after the program in a pane has exited, if "
		  "remain-on-exit is enabled."
	},

	{ .name = "scroll-on-clear",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_num = 1,
	  .text = "Whether the contents of the screen should be scrolled into"
		  "history when clearing the whole screen."
	},

	{ .name = "switch-mode-match-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_str = "bg=cyan fg=black",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of matched characters in switch mode."
	},

	{ .name = "synchronize-panes",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_num = 0,
	  .text = "Whether typing should be sent to all panes simultaneously."
	},

	{ .name = "tiled-layout-max-columns",
	  .type = OPTIONS_TABLE_NUMBER,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .minimum = 0,
	  .maximum = USHRT_MAX,
	  .default_num = 0,
	  .text = "Maximum number of columns in the 'tiled' layout. "
		  "A value of 0 means no limit."
	},

	{ .name = "tree-mode-border-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "bg=themedarkgrey,fg=themelightgrey",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of borders in tree mode."
	},

	{ .name = "tree-mode-preview-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_str = "#{?pane_format,"
			 "#{pane_index}:#{pane_title},"
			 "#{window_index}:#{window_name}}",
	  .text = "Format of the preview indicator in tree mode."
	},

	{ .name = "tree-mode-preview-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "fg=#{?#{||:"
			 "#{&&:#{pane_format},#{pane_active}},"
			 "#{&&:#{window_format},#{window_active}}},"
			 "themered,"
			 "themeblue}",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of preview indicator in tree mode."
	},

	{ .name = "tree-mode-selection-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "#{E:mode-style}",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the selected line in tree mode."
	},

	{ .name = "window-active-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_str = "default",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Default style of the active pane."
	},

	{ .name = "window-default-command",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "",
	  .text = "Default command to run in new panes. If set, "
		  "overrides 'default-command'."
	},

	{ .name = "window-pane-current-status-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "#P:[#T]#{?pane_flags,#{pane_flags}, }",
	  .text = "Format of the current window pane in the status line."
	},

	{ .name = "window-pane-status-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "#P:[#T]#{?pane_flags,#{pane_flags}, }",
	  .text = "Format of window panes in the status line, except the "
		  "current pane."
	},

	{ .name = "window-size",
	  .type = OPTIONS_TABLE_CHOICE,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .choices = options_table_window_size_list,
	  .default_num = WINDOW_SIZE_LATEST,
	  .text = "How window size is calculated. "
		  "'latest' uses the size of the most recently used client, "
		  "'largest' the largest client, 'smallest' the smallest "
		  "client and 'manual' a size set by the 'resize-window' "
		  "command."
	},

	{ .name = "window-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW|OPTIONS_TABLE_PANE,
	  .default_str = "default",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Default style of panes that are not the active pane."
	},

	{ .name = "window-status-activity-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "reverse",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of windows in the status line with an activity alert."
	},

	{ .name = "window-status-bell-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "reverse",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of windows in the status line with a bell alert."
	},

	{ .name = "window-status-current-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "#I:#W#{?window_flags,#{window_flags}, }",
	  .text = "Format of the current window in the status line."
	},

	{ .name = "window-status-current-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "underscore",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the current window in the status line."
	},

	{ .name = "window-status-format",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "#I:#W#{?window_flags,#{window_flags}, }",
	  .text = "Format of windows in the status line, except the current "
		  "window."
	},

	{ .name = "window-status-last-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "default",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of the last window in the status line."
	},

	{ .name = "window-status-separator",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = " ",
	  .text = "Separator between windows in the status line."
	},

	{ .name = "window-status-style",
	  .type = OPTIONS_TABLE_STRING,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_str = "default",
	  .flags = OPTIONS_TABLE_IS_STYLE,
	  .separator = ",",
	  .text = "Style of windows in the status line, except the current and "
		  "last windows."
	},

	{ .name = "wrap-search",
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_num = 1,
	  .text = "Whether searching in copy mode should wrap at the top or "
		  "bottom."
	},

	{ .name = "xterm-keys", /* no longer used */
	  .type = OPTIONS_TABLE_FLAG,
	  .scope = OPTIONS_TABLE_WINDOW,
	  .default_num = 1,
	  .text = "Whether xterm-style function key sequences should be sent. "
		  "This option is no longer used."
	},

	/* Hook options. */
	OPTIONS_TABLE_AFTER_HOOK("bind-key"),
	OPTIONS_TABLE_AFTER_HOOK("capture-pane"),
	OPTIONS_TABLE_AFTER_HOOK("copy-mode"),
	OPTIONS_TABLE_AFTER_HOOK("display-message"),
	OPTIONS_TABLE_AFTER_HOOK("display-panes"),
	OPTIONS_TABLE_AFTER_HOOK("kill-pane"),
	OPTIONS_TABLE_AFTER_HOOK("list-buffers"),
	OPTIONS_TABLE_AFTER_HOOK("list-clients"),
	OPTIONS_TABLE_AFTER_HOOK("list-keys"),
	OPTIONS_TABLE_AFTER_HOOK("list-panes"),
	OPTIONS_TABLE_AFTER_HOOK("list-sessions"),
	OPTIONS_TABLE_AFTER_HOOK("list-windows"),
	OPTIONS_TABLE_AFTER_HOOK("load-buffer"),
	OPTIONS_TABLE_AFTER_HOOK("lock-server"),
	OPTIONS_TABLE_AFTER_HOOK("new-session"),
	OPTIONS_TABLE_AFTER_HOOK("new-window"),
	OPTIONS_TABLE_AFTER_HOOK("paste-buffer"),
	OPTIONS_TABLE_AFTER_HOOK("pipe-pane"),
	OPTIONS_TABLE_AFTER_HOOK("refresh-client"),
	OPTIONS_TABLE_AFTER_HOOK("rename-session"),
	OPTIONS_TABLE_AFTER_HOOK("rename-window"),
	OPTIONS_TABLE_AFTER_HOOK("resize-pane"),
	OPTIONS_TABLE_AFTER_HOOK("resize-window"),
	OPTIONS_TABLE_AFTER_HOOK("save-buffer"),
	OPTIONS_TABLE_AFTER_HOOK("select-layout"),
	OPTIONS_TABLE_AFTER_HOOK("select-pane"),
	OPTIONS_TABLE_AFTER_HOOK("select-window"),
	OPTIONS_TABLE_AFTER_HOOK("send-keys"),
	OPTIONS_TABLE_AFTER_HOOK("set-buffer"),
	OPTIONS_TABLE_AFTER_HOOK("set-environment"),
	OPTIONS_TABLE_AFTER_HOOK("set-hook"),
	OPTIONS_TABLE_AFTER_HOOK("set-option"),
	OPTIONS_TABLE_AFTER_HOOK("show-environment"),
	OPTIONS_TABLE_AFTER_HOOK("show-messages"),
	OPTIONS_TABLE_AFTER_HOOK("show-options"),
	OPTIONS_TABLE_AFTER_HOOK("split-window"),
	OPTIONS_TABLE_AFTER_HOOK("swap-window"),
	OPTIONS_TABLE_AFTER_HOOK("unbind-key"),
	OPTIONS_TABLE_HOOK("alert-activity", "",
	    "Run when a window has activity."),
	OPTIONS_TABLE_HOOK("alert-bell", "",
	    "Run when a window has received a bell."),
	OPTIONS_TABLE_HOOK("alert-silence", "",
	    "Run when a window has been silent."),
	OPTIONS_TABLE_HOOK("client-active", "",
	    "Run when a client becomes the latest active client of its "
	    "session."),
	OPTIONS_TABLE_HOOK("client-attached", "",
	    "Run when a client is attached."),
	OPTIONS_TABLE_HOOK("client-created", "",
	    "Run when a client is created."),
	OPTIONS_TABLE_HOOK("client-closed", "",
	    "Run when a client is closed."),
	OPTIONS_TABLE_HOOK("client-detached", "",
	    "Run when a client is detached."),
	OPTIONS_TABLE_HOOK("client-focus-in", "",
	    "Run when focus enters a client."),
	OPTIONS_TABLE_HOOK("client-focus-out", "",
	    "Run when focus exits a client."),
	OPTIONS_TABLE_HOOK("client-resized", "",
	    "Run when a client is resized."),
	OPTIONS_TABLE_HOOK("client-session-changed", "",
	    "Run when a client's attached session is changed."),
	OPTIONS_TABLE_HOOK("client-light-theme", "",
	    "Run when a client switches to a light theme."),
	OPTIONS_TABLE_HOOK("client-dark-theme", "",
	    "Run when a client switches to a dark theme."),
	OPTIONS_TABLE_HOOK("command-error", "",
	    "Run when a command fails."),
	OPTIONS_TABLE_HOOK("marked-pane-changed", "",
	    "Run when the marked pane is set or cleared."),
	OPTIONS_TABLE_PANE_HOOK("pane-activity", "",
	    "Run when there is new output in a pane."),
	OPTIONS_TABLE_PANE_HOOK("pane-bell", "",
	    "Run when a pane receives a bell."),
	OPTIONS_TABLE_PANE_HOOK("pane-command-finished", "",
	    "Run when an OSC 133 command finishes in a pane."),
	OPTIONS_TABLE_PANE_HOOK("pane-command-started", "",
	    "Run when an OSC 133 command starts in a pane."),
	OPTIONS_TABLE_PANE_HOOK("pane-created", "",
	    "Run when a pane is created or respawned."),
	OPTIONS_TABLE_PANE_HOOK("pane-died", "",
	    "Run when the program running in a pane exits, but remain-on-exit "
	    "is on so the pane has not closed."),
	OPTIONS_TABLE_PANE_HOOK("pane-exited", "",
	    "Run when the program running in a pane exits."),
	OPTIONS_TABLE_PANE_HOOK("pane-focus-in", "",
	    "Run when the focus enters a pane, if the focus-events option is "
	    "on."),
	OPTIONS_TABLE_PANE_HOOK("pane-focus-out", "",
	    "Run when the focus exits a pane, if the focus-events option is "
	    "on."),
	OPTIONS_TABLE_PANE_HOOK("pane-mode-changed", "",
	    "Run when a pane changes mode."),
	OPTIONS_TABLE_PANE_HOOK("pane-mode-entered", "",
	    "Run when a pane enters a mode."),
	OPTIONS_TABLE_PANE_HOOK("pane-mode-exited", "",
	    "Run when a pane exits a mode."),
	OPTIONS_TABLE_PANE_HOOK("pane-moved", "",
	    "Run when a pane is moved to another window."),
	OPTIONS_TABLE_PANE_HOOK("pane-prompt-closed", "",
	    "Run when a prompt in a pane is closed."),
	OPTIONS_TABLE_PANE_HOOK("pane-prompt-opened", "",
	    "Run when a prompt is opened in a pane."),
	OPTIONS_TABLE_PANE_HOOK("pane-resized", "",
	    "Run when a pane is resized."),
	OPTIONS_TABLE_PANE_HOOK("pane-set-clipboard", "",
	    "Run when the terminal clipboard is set using the xterm escape "
	    "sequence."),
	OPTIONS_TABLE_PANE_HOOK("pane-shell-prompt", "",
	    "Run when an OSC 133 shell prompt starts in a pane."),
	OPTIONS_TABLE_PANE_HOOK("pane-title-changed", "",
	    "Run when a pane title is changed."),
	OPTIONS_TABLE_HOOK("session-closed", "",
	    "Run when a session is closed."),
	OPTIONS_TABLE_HOOK("session-created", "",
	    "Run when a new session is created."),
	OPTIONS_TABLE_HOOK("session-added-to-group", "",
	    "Run when a session is added to a session group."),
	OPTIONS_TABLE_HOOK("session-renamed", "",
	    "Run when a session is renamed."),
	OPTIONS_TABLE_HOOK("session-removed-from-group", "",
	    "Run when a session is removed from a session group."),
	OPTIONS_TABLE_HOOK("session-window-changed", "",
	    "Run when a session changes its active window."),
	OPTIONS_TABLE_WINDOW_HOOK("window-created", "",
	    "Run when a window is created."),
	OPTIONS_TABLE_WINDOW_HOOK("window-closed", "",
	    "Run when a window is closed."),
	OPTIONS_TABLE_WINDOW_HOOK("window-layout-changed", "",
	    "Run when a window layout is changed."),
	OPTIONS_TABLE_HOOK("window-linked", "",
	    "Run when a window is linked into a session."),
	OPTIONS_TABLE_WINDOW_HOOK("window-pane-changed", "",
	    "Run when a window changes its active pane."),
	OPTIONS_TABLE_WINDOW_HOOK("window-renamed", "",
	    "Run when a window is renamed."),
	OPTIONS_TABLE_WINDOW_HOOK("window-resized", "",
	    "Run when a window is resized. This may be after the "
	    "client-resized hook is run."),
	OPTIONS_TABLE_WINDOW_HOOK("window-unzoomed", "",
	    "Run when a window is unzoomed."),
	OPTIONS_TABLE_WINDOW_HOOK("window-zoomed", "",
	    "Run when a window is zoomed."),
	OPTIONS_TABLE_HOOK("window-unlinked", "",
	    "Run when a window is unlinked from a session."),

	{ .name = NULL }
};
