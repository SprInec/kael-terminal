/* $OpenBSD: cmd-break-pane.c,v 1.77 2026/10/09 13:12:14 nicm Exp $ */

/*
 * Copyright (c) 2009 Nicholas Marriott <nicholas.marriott@gmail.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF MIND, USE, DATA OR PROFITS, WHETHER
 * IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/types.h>

#include <stdlib.h>

#include "tmux.h"

/*
 * Break pane off into a window.
 */

#define BREAK_PANE_TEMPLATE "#{session_name}:#{window_index}.#{pane_index}"

static enum cmd_retval	cmd_break_pane_exec(struct cmd *, struct cmdq_item *);

const struct cmd_entry cmd_break_pane_entry = {
	.name = "break-pane",
	.description = "Move a pane into its own window or make it floating.",
	.alias = "breakp",

	.args = { "abdPF:n:s:t:Wx:X:y:Y:", 0, 0, NULL },
	.usage = "[-abdPW] [-F format] [-n window-name] [-s src-pane] "
		 "[-t dst-window] [-x width] [-y height] [-X x-position] "
		 "[-Y y-position]",

	.source = { 's', CMD_FIND_PANE, 0 },
	.target = { 't', CMD_FIND_WINDOW, CMD_FIND_WINDOW_INDEX },

	.flags = 0,
	.exec = cmd_break_pane_exec
};

static enum cmd_retval
cmd_break_pane_float(struct cmdq_item *item, struct args *args,
    struct window *w, struct window_pane *wp)
{
	struct layout_cell	*lc = wp->layout_cell;
	char			*cause = NULL;
	enum pane_lines		 lines = window_get_pane_lines(w);
	struct layout_geometry	*fg = &lc->fg;

	if (window_pane_is_floating(wp)) {
		cmdq_error(item, "pane is already floating");
		return (CMD_RETURN_ERROR);
	}
	if (w->flags & WINDOW_ZOOMED) {
		cmdq_error(item, "can't float a pane while window is zoomed");
		return (CMD_RETURN_ERROR);
	}

	if (layout_floating_args_parse(item, args, lines, w, fg, &cause) != 0) {
		cmdq_error(item, "failed to float pane: %s", cause);
		free(cause);
		return (CMD_RETURN_ERROR);
	}
	layout_remove_tile(w, lc);
	layout_set_size(lc, fg->sx, fg->sy, fg->xoff, fg->yoff);

	lc->flags |= LAYOUT_CELL_FLOATING;
	TAILQ_REMOVE(&w->z_index, wp, zentry);
	TAILQ_INSERT_HEAD(&w->z_index, wp, zentry);

	if (!args_has(args, 'd'))
		window_set_active_pane(w, wp, 1);
	layout_fix_offsets(w);
	layout_fix_panes(w, NULL);
	events_fire_window("window-layout-changed", w);
	server_redraw_window(w);

	return (CMD_RETURN_NORMAL);
}

static enum cmd_retval
cmd_break_pane_exec(struct cmd *self, struct cmdq_item *item)
{
	struct args		*args = cmd_get_args(self);
	struct cmd_find_state	*current = cmdq_get_current(item);
	struct cmd_find_state	*target = cmdq_get_target(item);
	struct cmd_find_state	*source = cmdq_get_source(item);
	struct client		*tc = cmdq_get_target_client(item);
	struct winlink		*wl = source->wl;
	struct session		*src_s = source->s;
	struct session		*dst_s = target->s;
	struct window_pane	*wp = source->wp;
	struct window		*w = wl->window, *old_w = w;
	char			*cause, *cp;
	int			 idx = target->idx, before, old_idx = wl->idx;
	const char		*template, *name = args_get(args, 'n');

	if (wp == w->modal) {
		cmdq_error(item, "pane is modal");
		return (CMD_RETURN_ERROR);
	}

	if (args_has(args, 'W'))
		return (cmd_break_pane_float(item, args, w, wp));

	if (name != NULL && !check_name(name)) {
		cmdq_error(item, "invalid window name: %s", name);
		return (CMD_RETURN_ERROR);
	}

	before = args_has(args, 'b');
	if (args_has(args, 'a') || before) {
		if (target->wl != NULL)
			idx = winlink_shuffle_up(dst_s, target->wl, before);
		else
			idx = winlink_shuffle_up(dst_s, dst_s->curw, before);
		if (idx == -1)
			return (CMD_RETURN_ERROR);
	}
	server_unzoom_window(w);

	if (window_count_panes(w, 1) == 1) {
		if (server_link_window(src_s, wl, dst_s, idx, 0,
		    !args_has(args, 'd'), &cause) != 0) {
			cmdq_error(item, "%s", cause);
			free(cause);
			return (CMD_RETURN_ERROR);
		}
		if (name != NULL) {
			window_set_name(w, name, 0);
			options_set_number(w->options, "automatic-rename", 0);
		}
		server_unlink_window(src_s, wl);
		wl = winlink_find_by_window(&dst_s->windows, w);
		if (wl == NULL)
			return (CMD_RETURN_ERROR);
		window_fire_pane_moved(wp, old_w, old_idx, w, wl->idx);
		goto out;
	}
	if (idx != -1 && winlink_find_by_index(&dst_s->windows, idx) != NULL) {
		cmdq_error(item, "index in use: %d", idx);
		return (CMD_RETURN_ERROR);
	}

	TAILQ_REMOVE(&w->panes, wp, entry);
	TAILQ_REMOVE(&w->z_index, wp, zentry);
	server_client_remove_pane(wp);
	window_lost_pane(w, wp);
	layout_close_pane(wp);

	w = wp->window = window_create(w->sx, w->sy, w->xpixel, w->ypixel);
	window_add_ref(w, __func__);
	options_set_parent(wp->options, w->options);
	wp->flags |= (PANE_STYLECHANGED|PANE_THEMECHANGED);
	TAILQ_INSERT_HEAD(&w->panes, wp, entry);
	TAILQ_INSERT_HEAD(&w->z_index, wp, zentry);
	w->active = wp;
	w->latest = tc;

	free(w->name);
	if (name == NULL)
		w->name = default_window_name(w);
	else {
		w->name = clean_name(name, 0);
		options_set_number(w->options, "automatic-rename", 0);
	}
	window_set_fill_cells(w);

	if (idx == -1)
		idx = -1 - options_get_number(dst_s->options, "base-index");
	wl = session_attach(dst_s, w, idx, &cause); /* can't fail */

	layout_init(w, wp);
	wp->flags |= PANE_CHANGED;
	colour_palette_from_option(&wp->palette, wp->options);

	window_remove_ref(w, __func__);
	events_fire_window("window-created", w);
	window_fire_pane_moved(wp, old_w, old_idx, w, wl->idx);
	if (!args_has(args, 'd')) {
		session_select(dst_s, wl->idx);
		cmd_find_from_session(current, dst_s, 0);
	}

	server_redraw_session(src_s);
	if (src_s != dst_s)
		server_redraw_session(dst_s);
	server_status_session_group(src_s);
	if (src_s != dst_s)
		server_status_session_group(dst_s);

out:
	if (args_has(args, 'P')) {
		if ((template = args_get(args, 'F')) == NULL)
			template = BREAK_PANE_TEMPLATE;
		cp = format_single(item, template, tc, dst_s, wl, wp);
		cmdq_print(item, "%s", cp);
		free(cp);
	}
	return (CMD_RETURN_NORMAL);
}
